package dev.danzy.morewheels;

import com.mojang.logging.LogUtils;
import dev.danzy.morewheels.compat.OffroadCompat;
import dev.danzy.morewheels.registry.ModCreativeTabs;
import dev.danzy.morewheels.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(MoreWheels.MOD_ID)
public class MoreWheels {
    public static final String MOD_ID = "morewheels";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MoreWheels() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(bus);
        ModCreativeTabs.register(bus);
        bus.addListener(OffroadCompat::onCommonSetup);
        LOGGER.info("[More Wheels] initialised with {} wheel(s)", ModItems.wheels().size());
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
