package dev.danzy.morewheels.compat;

import dev.danzy.morewheels.MoreWheels;
import dev.danzy.morewheels.content.WheelDefinition;
import dev.danzy.morewheels.registry.ModItems;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Optional;

/**
 * Registra o "tire" padrao de cada roda no Offroad (OffroadDataComponents.TIRE.registerDefault).
 * Usa reflexao de proposito: assim o mod compila sem o jar do Offroad/Aeronautics.
 */
public final class OffroadCompat {
    private OffroadCompat() {}

    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(OffroadCompat::attachTires);
    }

    private static void attachTires() {
        try {
            Class<?> components = Class.forName("dev.ryanhcode.offroad.index.OffroadDataComponents");
            Object tireType = components.getField("TIRE").get(null);
            Class<?> tireLike = Class.forName("dev.ryanhcode.offroad.content.components.TireLike");
            Constructor<?> ctor = tireLike.getConstructor(float.class, Vec3.class, Vec3.class, Optional.class, float.class);

            Method register = null;
            for (Method m : tireType.getClass().getMethods()) {
                if (m.getName().equals("registerDefault") && m.getParameterCount() == 2) {
                    register = m;
                    break;
                }
            }
            if (register == null) {
                MoreWheels.LOGGER.error("[More Wheels] Offroad TIRE.registerDefault not found - wheels will be inert.");
                return;
            }

            for (ModItems.WheelEntry entry : ModItems.wheels()) {
                WheelDefinition def = entry.definition();
                try {
                    Object tire = ctor.newInstance(def.radius(), def.rotation(), def.offset(),
                            Optional.ofNullable(def.model()), def.minimumFriction());
                    register.invoke(tireType, entry.item().get(), tire);
                    MoreWheels.LOGGER.debug("[More Wheels] attached tire data to {}", entry.item().getId());
                } catch (ReflectiveOperationException | RuntimeException e) {
                    MoreWheels.LOGGER.error("[More Wheels] failed to build tire data for {}", entry.item().getId(), e);
                }
            }
        } catch (ClassNotFoundException e) {
            MoreWheels.LOGGER.error("[More Wheels] Offroad is not installed. Wheels will be inert.");
        } catch (ReflectiveOperationException | RuntimeException e) {
            MoreWheels.LOGGER.error("[More Wheels] could not hook into Offroad", e);
        }
    }
}
