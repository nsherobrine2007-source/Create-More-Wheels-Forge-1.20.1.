package dev.danzy.morewheels.content;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

public record WheelDefinition(float radius, Vec3 rotation, Vec3 offset, float minimumFriction, ResourceLocation model) {
    public static final Vec3 AXLE_Y = new Vec3(90.0, 0.0, 0.0);
    public static final Vec3 AXLE_Y_FLIPPED = new Vec3(270.0, 0.0, 0.0);

    public static WheelDefinition simple(float radius, Vec3 rotation, float minimumFriction) {
        return new WheelDefinition(radius, rotation, Vec3.ZERO, minimumFriction, null);
    }
}
