package dev.danzy.morewheels.registry;

import dev.danzy.morewheels.MoreWheels;
import dev.danzy.morewheels.content.WheelDefinition;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoreWheels.MOD_ID);
    // Precisa vir antes dos wheel(...) abaixo.
    private static final List<WheelEntry> WHEELS = new ArrayList<>();

    public static final RegistryObject<Item> SIMPLE_WHEEL = wheel("simple_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y_FLIPPED, 0.55f));
    public static final RegistryObject<Item> SOVIET_SMALL_WHEEL = wheel("soviet_small_wheel", WheelDefinition.simple(0.8f, WheelDefinition.AXLE_Y_FLIPPED, 0.6f));
    public static final RegistryObject<Item> STEEL_SMALL_WHEEL = wheel("steel_small_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> CLASSIC_WHEEL = wheel("classic_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> SPORT_WHEEL = wheel("sport_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> DRAG_WHEEL = wheel("drag_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> POWER_WHEEL = wheel("power_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> SPOKE_WHEEL = wheel("spoke_wheel", WheelDefinition.simple(0.75f, WheelDefinition.AXLE_Y, 0.5f));
    public static final RegistryObject<Item> SOVIET_WHEEL = wheel("soviet_wheel", WheelDefinition.simple(0.96875f, WheelDefinition.AXLE_Y_FLIPPED, 0.5f));
    public static final RegistryObject<Item> SOVIET_LARGE_WHEEL = wheel("soviet_large_wheel", WheelDefinition.simple(1.25f, WheelDefinition.AXLE_Y_FLIPPED, 0.55f));
    public static final RegistryObject<Item> SEMI_TRUCK_TIRE = wheel("semi-truck_tire", WheelDefinition.simple(0.96875f, WheelDefinition.AXLE_Y_FLIPPED, 0.6f));
    public static final RegistryObject<Item> URAL_TIRE = wheel("ural_tire", WheelDefinition.simple(1.09375f, WheelDefinition.AXLE_Y_FLIPPED, 0.65f));
    public static final RegistryObject<Item> SMALL_SEMI_TRUCK_TIRE = wheel("small-semi-truck_tire", WheelDefinition.simple(0.8f, WheelDefinition.AXLE_Y_FLIPPED, 0.6f));
    public static final RegistryObject<Item> TRACTOR_TIRE = wheel("tractor_tire", WheelDefinition.simple(1.25f, WheelDefinition.AXLE_Y_FLIPPED, 0.7f));
    public static final RegistryObject<Item> SMALL_TRACTOR_TIRE = wheel("small-tractor_tire", WheelDefinition.simple(0.96875f, WheelDefinition.AXLE_Y_FLIPPED, 0.7f));

    private ModItems() {}

    private static RegistryObject<Item> wheel(String name, WheelDefinition definition) {
        RegistryObject<Item> item = ITEMS.register(name, () -> new Item(new Item.Properties().stacksTo(16)));
        WHEELS.add(new WheelEntry(item, definition));
        return item;
    }

    public static List<WheelEntry> wheels() {
        return List.copyOf(WHEELS);
    }

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }

    public record WheelEntry(RegistryObject<Item> item, WheelDefinition definition) {}
}
